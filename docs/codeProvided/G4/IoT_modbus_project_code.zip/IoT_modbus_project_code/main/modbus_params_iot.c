#include "modbus_params_iot.h"


holding_reg_params_t holding_reg_params_iot = { 0 };
input_reg_params_t input_reg_params_iot  = { 0 };
coil_reg_params_t coil_reg_params_iot  = { 0 };
discrete_reg_params_t discrete_reg_params_iot  = { 0 };