#include <stdio.h>
void init_display(void);
void print_display(const char *string, uint16_t width, int16_t x_pos, int16_t y_pos);