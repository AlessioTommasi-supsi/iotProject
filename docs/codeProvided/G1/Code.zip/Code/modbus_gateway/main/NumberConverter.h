#ifndef NumberConverter_h
#define NumberConverter_h

#include <Arduino.h>

class NumberConverter {
  public:
    static float uint32ToFloat(uint32_t uintValue);
    static uint32_t floatToUint32(float floatValue);
};

#endif
