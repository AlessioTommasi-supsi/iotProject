#ifndef HoldingRegister_h
#define HoldingRegister_h

#include <Arduino.h>
// #include <stdint.h>

class HoldingRegister {
  public:
    enum VariableType {
      HR_INTEGER = 1,
      HR_FLOAT = 2,
      HR_BINARY = 3,
      HR_HEX = 4,
      HR_UNSIGNED_DECIMAL = 5,
      HR_LONG_INTEGER = 6,
      HR_DOUBLE_FLOAT = 7
    };

    HoldingRegister();
    HoldingRegister(const uint8_t slaveAddress, const uint16_t registerAddress, const VariableType type, const bool readWrite, const String label, const String description, const String unit, const int minValue = -1, const int maxValue = -1);
    // HoldingRegister(const HoldingRegister& other);

    // HoldingRegister& operator=(const HoldingRegister& other);

    void setValue(String value) {_value = value;};
    
    uint8_t getSlaveAddress() const {return _slaveAddress;};
    uint16_t getRegisterAddress() const {return _registerAddress;};
    VariableType getType() const {return _type;};
    bool isReadWrite() const {return _readWrite;};
    String getLabel() const {return _label;};
    String getDescription() const {return _description;};
    int getMinValue() const {return _minValue;};
    int getMaxValue() const {return _maxValue;};
    String getUnit() const {return _unit;};
    String getValue() const {return _value;};

    String toString() const;

  private:
    uint8_t _slaveAddress;
    uint16_t _registerAddress;
    VariableType _type;
    // false = READONLY, true = READWRITE
    bool _readWrite;
    String _label;
    String _description;
    int _minValue = -1;
    int _maxValue = -1;
    String _unit;
    String _value = "-1";

    void _setMinValue(int minValue);
    void _setMaxValue(int maxValue);
  
};

#endif
