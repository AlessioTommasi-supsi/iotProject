#include "NumberConverter.h"
#include <cstdint>

float NumberConverter::uint32ToFloat(uint32_t uintValue) {
    float floatValue;
    memcpy(&floatValue, &uintValue, sizeof(floatValue));
    return floatValue;
}

uint32_t NumberConverter::floatToUint32(float floatValue) {
    uint32_t uintValue;
    memcpy(&uintValue, &floatValue, sizeof(uintValue));
    return uintValue;
}