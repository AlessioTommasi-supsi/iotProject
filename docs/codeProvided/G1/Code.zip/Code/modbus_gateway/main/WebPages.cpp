#include "WebPages.h"

String WebPages::getCaptivePortal(){
  return R"rawliteral(
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WiFi Setup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            margin: 0 auto;
            max-width: 600px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
        }

        select,
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button.connect {
            background-color: #007bff;
            color: white;
        }

        button.connect:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            margin-top: 20px;
        }

        .spinner {
            margin: 0 auto;
            border: 6px solid #f3f3f3;
            border-top: 6px solid #007bff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .spinner-container {
            text-align: center;
            margin-top: 20px;
        }

        .password-container {
            display: flex;
            align-items: center;
        }

        .password-container input {
            flex: 1;
        }

        .password-container label {
            margin-left: 10px;
            font-weight: normal;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <h1>WiFi Setup</h1>
    <div class="form-container">
        <div id="spinner" class="spinner-container" style="display:none;">
          <div class="spinner"></div>
        </div>
        <form id="wifiForm">
            <label for="ssid">Select WiFi network:</label>
            <select id="ssid" name="ssid" required></select>
            <label for="password">Insert password:</label>
            <div class="password-container">
              <input type="password" name="password" id="password" placeholder="Password" required>
              <label>
                <input type="checkbox" id="togglePassword"> Show
              </label>
            </div>
            <button class="connect" type="submit">Connect</button>
        </form>
        <div id="message" class="message"></div>
    </div>

    <script src="captivePortalScript.js"></script>
</body>

</html>
)rawliteral";
}

String WebPages::getCaptivePortalJs(){
  return R"rawliteral(
    async function fetchNetworks() {
      const select = document.getElementById('ssid');
      if(select.innerHTML == ''){
        document.getElementById('spinner').style.display = 'block';
      }
      const response = await fetch('/scanNetworks');
      const networks = await response.json();
      if (networks.length > 0){
        select.innerHTML = '';
      }
      networks.forEach(network => {
        const option = document.createElement('option');
        option.value = network.ssid;
        option.textContent = `${network.ssid} (${network.rssi} dBm)`;
        select.appendChild(option);
      });
      document.getElementById('spinner').style.display = 'none';
    }

    async function connectToWifi(event) {
      event.preventDefault();
      document.getElementById('spinner').style.display = 'block';
      const form = document.getElementById('wifiForm');
      const formData = new FormData(form);

      const response = await fetch('/connect', {
        method: 'POST',
        body: formData
      });

      const result = await response.text();
      const messageDiv = document.getElementById('message');

      if (response.ok) {
        messageDiv.innerHTML = `Connected successfully! New IP: <a href="http://${result}/configuration" target="_blank">${result}</a>`;
        setTimeout(() => {
          window.location.href = `http://${result}/configuration`;
        }, 10000); // Redirect after 10 seconds
      } else {
        messageDiv.textContent = `Failed to connect: ${result}`;
      }
      document.getElementById('spinner').style.display = 'none';
    }

    document.getElementById('wifiForm').addEventListener('submit', connectToWifi);

    document.getElementById('togglePassword').addEventListener('change', function () {
      const passwordField = document.getElementById('password');
      if (this.checked) {
        passwordField.type = 'text';
      } else {
        passwordField.type = 'password';
      }
    });

    //Periodical
    setInterval(fetchNetworks, 15000);

    fetchNetworks();
  )rawliteral";
}

String WebPages::getConfigurationPage() {
  return R"rawliteral(
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESP32 Data Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        td.label,
        td.description,
        td.unit {
            text-align: left;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e9f5ff;
        }

        button {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        button.edit {
            background-color: #ffc107;
            color: white;
        }

        button.edit:hover {
            background-color: #e0a800;
        }

        button.delete {
            background-color: #dc3545;
            color: white;
        }

        button.delete:hover {
            background-color: #c82333;
        }

        button.save {
            background-color: #28a745;
            color: white;
        }

        button.save:hover {
            background-color: #218838;
        }

        button.cancel {
            background-color: #6c757d;
            color: white;
        }

        button.cancel:hover {
            background-color: #5a6268;
        }

        .add-button {
            background-color: #007bff;
            color: white;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: auto 20px auto auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }

        .add-button:hover {
            background-color: #0056b3;
        }

        /* Toggle Switch styling */
        .toggle-switch {
            position: relative;
            width: 50px;
            height: 25px;
            display: inline-block;
            margin-right: auto;
        }

        .toggle-switch input {
            display: none;
        }

        .toggle-switch-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 25px;
        }

        .toggle-switch-slider:before {
            position: absolute;
            content: "";
            height: 21px;
            width: 21px;
            left: 2px;
            bottom: 2px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked+.toggle-switch-slider {
            background-color: #007bff;
        }

        input:checked+.toggle-switch-slider:before {
            transform: translateX(24px);
        }

        /* Modal styling */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .form-row {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin-bottom: 10px;
            width: 100%;
        }

        .form-row label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-row input[type="number"],
        .form-row input[type="text"],
        .form-row select,
        .form-row input[type="checkbox"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-row.checkbox-row {
            flex-direction: row;
            align-items: center;
        }

        .form-row.checkbox-row label {
            margin-bottom: 0;
            display: flex;
            align-items: center;
        }

        .form-row input[type="checkbox"] {
            width: auto;
            margin-left: 10px;
            margin-top: 0;
            margin-bottom: 0;
        }

        .form-row.form-actions {
            flex-direction: row;
            justify-content: flex-end;
            width: 100%;
        }

        .form-row button {
            margin-left: 10px;
        }

        /* Responsive design for the form */
        @media (min-width: 768px) {
            .form-row {
                justify-content: space-between;
            }

            .form-row label {
                flex: 0 0 30%;
            }

            .form-row input[type="number"],
            .form-row input[type="text"],
            .form-row select {
                flex: 0 0 65%;
            }
        }
    </style>
</head>

<body>
    <h1>ESP32 Data Table</h1>

    <table id="dataTable">
        <thead>
            <tr>
                <th>Slave Address</th>
                <th>Register Address</th>
                <th>Type</th>
                <th>Read/Write</th>
                <th>Label</th>
                <th>Description</th>
                <th>Unit</th>
                <th>Value</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Data rows will be inserted here by JavaScript -->
        </tbody>
    </table>
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <label style="margin-right: 10px;">Slave mode</label>
        <label class="toggle-switch">
            <input type="checkbox" id="slaveModeSwitch" onclick="toggleSlaveMode()">
            <span class="toggle-switch-slider"></span>
        </label>
        <div class="add-button" onclick="showAddForm()">+</div>
    </div>
    <div style="display: flex; justify-content: flex-start; align-items: center;">
        <label style="margin-right: 10px;">Swap mode</label>
        <label class="toggle-switch">
            <input type="checkbox" id="swapModeSwitch" onclick="toggleSwapMode()">
            <span class="toggle-switch-slider"></span>
        </label>
    </div>

    <!-- The Modal -->
    <div id="addFormModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close" onclick="hideAddForm()">&times;</span>
            <h2>Item</h2>
            <div class="form-row">
                <label for="newSlaveAddress">Slave Address:</label>
                <input type="number" id="newSlaveAddress" required>
            </div>
            <div class="form-row">
                <label for="newRegisterAddress">Register Address:</label>
                <input type="number" id="newRegisterAddress" required>
            </div>
            <div class="form-row">
                <label for="newType">Type:</label>
                <select id="newType" required></select>
            </div>
            <div class="form-row checkbox-row">
                <label for="newReadWrite">Read/Write: <input type="checkbox" id="newReadWrite"></label>
            </div>
            <div class="form-row">
                <label for="newLabel">Label:</label>
                <input type="text" id="newLabel">
            </div>
            <div class="form-row">
                <label for="newDescription">Description:</label>
                <input type="text" id="newDescription">
            </div>
            <div class="form-row">
                <label for="newUnit">Unit:</label>
                <input type="text" id="newUnit">
            </div>
            <div class="form-row form-actions">
                <button class="cancel" onclick="hideAddForm()">Cancel</button>
                <button class="save" onclick="addNewItem()">Save</button>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="configurationScript.js"></script>
</body>

</html>
)rawliteral";
}

String WebPages::getConfigurationPageJs() {
  return R"rawliteral(
document.addEventListener('DOMContentLoaded', () => {
  populateTypeSelect();
  fetchTableData();
});

const RegisterType = {
  INTEGER: 1,
  FLOAT: 2,
  BINARY: 3,
  HEX: 4,
  UNSIGNED_DECIMAL: 5,
  LONG_INTEGER: 6,
  DOUBLE_FLOAT: 7
};

const RegisterTypeReverse = {
  1: 'INTEGER',
  2: 'FLOAT',
  3: 'BINARY',
  4: 'HEX',
  5: 'UNSIGNED_DECIMAL',
  6: 'LONG_INTEGER',
  7: 'DOUBLE_FLOAT'
};

const dataHistory = {}; // Object to store the history of values for each register
let chart;

function populateTypeSelect() {
  const typeSelect = document.getElementById('newType');
  for (const [key, value] of Object.entries(RegisterType)) {
    const option = document.createElement('option');
    option.value = value;
    option.text = key;
    typeSelect.appendChild(option);
  }
}

function addActionButton(cell, text, onClickFunction) {
  const button = document.createElement('button');
  button.textContent = text;
  button.classList.add(text.toLowerCase());
  button.onclick = onClickFunction;
  cell.appendChild(button);
}

function fetchTableData() {
  fetch('/holdingRegisters')
    .then(response => response.json())
    .then(data => {
      const tableBody = document.querySelector('#dataTable tbody');
      tableBody.innerHTML = '';
      data.forEach((item, index) => {

        // Update data history object
        if (!dataHistory[item.registerAddress]) {
          dataHistory[item.registerAddress] = [];
        }
        dataHistory[item.registerAddress].push({
          timestamp: new Date().toLocaleTimeString(),
          value: item.value
        });

        const row = tableBody.insertRow(index);
        row.insertCell(0).textContent = item.slaveAddress;
        row.insertCell(1).textContent = item.registerAddress;
        row.insertCell(2).textContent = RegisterTypeReverse[item.type];
        row.insertCell(3).textContent = item.readWrite ? 'RW' : 'RO';
        row.insertCell(4).textContent = item.label;
        row.insertCell(5).textContent = item.description;
        row.insertCell(6).textContent = item.unit;

        const valueCell = row.insertCell(7);
        valueCell.innerHTML = `${item.value} <span class="arrow" onclick="showGraphPopup(${item.registerAddress})">➜</span>`;
        valueCell.style.cursor = 'pointer'; // Change cursor to pointer to indicate clickability

        // Style for the arrow to appear closely linked to the value
        const arrowSpan = valueCell.querySelector('.arrow');
        arrowSpan.style.cursor = 'pointer';
        arrowSpan.style.color = '#007bff'; // Example color, choose what fits your design
        arrowSpan.style.marginLeft = '5px'; // Add some space between the value and the arrow

        const actionsCell = row.insertCell(8);
        addActionButton(actionsCell, 'Edit', () => edit(index));
        addActionButton(actionsCell, 'Delete', () => deleteRow(item.registerAddress));
      });
    })
    .catch(error => console.error('Error fetching data:', error));
}

function fetchSingleRegister(registerAddress) {
  fetch(`/holdingRegister?address=${registerAddress}`)
    .then(response => response.json())
    .then(data => {
      dataHistory[data.registerAddress].push({
        timestamp: new Date().toLocaleTimeString(),
        value: data.value
      });

      if (document.getElementById(`graphPopup${registerAddress}`)) {
        setTimeout(() => fetchSingleRegister(registerAddress), 5000);

        drawGraph('graphCanvas', registerAddress);

        const lastValueElement = document.getElementById('lastValue');
        if (lastValueElement) {
          lastValueElement.textContent = `Last Value: ${data.value}`
        }
      }
    })
    .catch(error => console.error('Error fetching last value:', error));

}

function edit(index) {
  const table = document.getElementById('dataTable');
  const row = table.rows[index + 1];

  const slaveAddress = row.cells[0].textContent;
  const registerAddress = row.cells[1].textContent;
  const type = row.cells[2].textContent;
  const readWrite = row.cells[3].textContent == 'RW' ? true : false;
  const label = row.cells[4].textContent;
  const description = row.cells[5].textContent;
  const unit = row.cells[6].textContent;

  // Populate the modal with current values
  document.getElementById('newSlaveAddress').value = slaveAddress;
  document.getElementById('newRegisterAddress').value = registerAddress;
  document.getElementById('newType').value = RegisterType[type];
  document.getElementById('newReadWrite').checked = readWrite;
  document.getElementById('newLabel').value = label;
  document.getElementById('newDescription').value = description;
  document.getElementById('newUnit').value = unit;

  showAddForm();

  const saveButton = document.querySelector('.modal-content .save');
  saveButton.onclick = function () {
    editLogic(index);
  };
}

function editLogic(index) {
  const table = document.getElementById('dataTable');
  const row = table.rows[index + 1]; // +1 to skip the header row

  const formData = new FormData();
  formData.append('slaveAddress', parseInt(document.getElementById('newSlaveAddress').value, 10));
  formData.append('registerAddress', parseInt(document.getElementById('newRegisterAddress').value, 10));
  formData.append('type', parseInt(document.getElementById('newType').value, 10));
  formData.append('readWrite', document.getElementById('newReadWrite').checked ? 1 : 0);
  formData.append('label', document.getElementById('newLabel').value);
  formData.append('description', document.getElementById('newDescription').value);
  formData.append('unit', document.getElementById('newUnit').value);

  if (parseInt(row.cells[1].textContent, 10) == parseInt(document.getElementById('newRegisterAddress').value, 10)) {
    editCall(formData);
  } else {
    const deleteFormData = new FormData();
    deleteFormData.append('registerAddress', parseInt(row.cells[1].textContent, 10));
    deleteCall(deleteFormData);

    addNewItem();
  }
}

function editCall(formData) {
  fetch('/edit', {
    method: 'PUT',
    body: formData,
  })
    .then(response => response.text())
    .then(data => {
      console.log(data);
      hideAddForm();
      fetchTableData();
    })
    .catch(error => console.error('Error updating data:', error));
}

function deleteRow(registerAddress) {
  if (confirm('Are you sure you want to delete this row?')) {
    const formData = new FormData();
    formData.append('registerAddress', parseInt(registerAddress, 10));
    deleteCall(formData);
  }
}

function deleteCall(formData) {
  fetch(`/delete`, {
    method: 'DELETE',
    body: formData
  })
    .then(response => response.text())
    .then(data => {
      console.log(data);
      fetchTableData();
    })
    .catch(error => console.error('Error deleting data:', error));
}

function addNewItem() {
  const formData = new FormData();
  formData.append('slaveAddress', parseInt(document.getElementById('newSlaveAddress').value, 10));
  formData.append('registerAddress', parseInt(document.getElementById('newRegisterAddress').value, 10));
  formData.append('type', parseInt(document.getElementById('newType').value, 10));
  formData.append('readWrite', document.getElementById('newReadWrite').checked ? 1 : 0);
  formData.append('label', document.getElementById('newLabel').value);
  formData.append('description', document.getElementById('newDescription').value);
  formData.append('unit', document.getElementById('newUnit').value);

  addCall(formData);
}

function addCall(formData) {
  fetch('/add', {
    method: 'POST',
    body: formData
  })
    .then(response => response.text())
    .then(data => {
      hideAddForm();
      fetchTableData();
    })
    .catch(error => console.error('Error adding new item:', error));
}

function toggleSlaveMode() {
  const toggleSwitch = document.getElementById('slaveModeSwitch');
  const slaveMode = toggleSwitch.checked;

  const formData = new FormData();
  formData.append('slave', slaveMode ? 1 : 0);

  toggleSlaveCall(formData);
}

function toggleSlaveCall(formData) {
  fetch('/slave', {
    method: 'PUT',
    body: formData
  })
    .then(response => response.text())
    .then(data => {
      console.log(data);
    })
    .catch(error => console.error('Error:', error));
}

function toggleSwapMode() {
  const toggleSwitch = document.getElementById('swapModeSwitch');
  const swapMode = toggleSwitch.checked;

  const formData = new FormData();
  formData.append('swap', swapMode ? 1 : 0);

  toggleSwapCall(formData);
}

function toggleSwapCall(formData) {
  fetch('/swap', {
    method: 'PUT',
    body: formData
  })
    .then(response => response.text())
    .then(data => {
      console.log(data);
    })
    .catch(error => console.error('Error:', error));
}

function showAddForm() {
  document.getElementById('addFormModal').style.display = "flex";
}

function resetForm() {
  document.getElementById('newSlaveAddress').value = '';
  document.getElementById('newRegisterAddress').value = '';
  document.getElementById('newType').value = '';
  document.getElementById('newReadWrite').checked = false;
  document.getElementById('newLabel').value = '';
  document.getElementById('newDescription').value = '';
  document.getElementById('newUnit').value = '';

  // Reset the save button to its original function
  const saveButton = document.querySelector('.modal-content .save');
  saveButton.onclick = addNewItem;
}

function hideAddForm() {
  document.getElementById('addFormModal').style.display = "none";

  resetForm();
}

window.onclick = function (event) {
  const modal = document.getElementById('addFormModal');
  if (event.target == modal) {
    modal.style.display = "none";

    resetForm();
  }
}

function showGraphPopup(registerAddress) {
  const existingPopup = document.getElementById(`graphPopup${registerAddress}`);
  if (existingPopup) {
    document.body.removeChild(existingPopup);
  }

  // Create a pop-up window or a modal
  const popup = document.createElement('div');
  popup.id = `graphPopup${registerAddress}`;
  popup.style.position = 'fixed';
  popup.style.top = '50%';
  popup.style.left = '50%';
  popup.style.transform = 'translate(-50%, -50%)';
  popup.style.border = '1px solid #ccc';
  popup.style.background = '#fff';
  popup.style.padding = '20px';
  popup.style.zIndex = '1000';
  popup.style.width = '60%'; // Adjusted width for better layout
  popup.style.maxWidth = '640px'; // Max width for large screens
  popup.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)'; // Soft shadow for 3D effect
  popup.style.borderRadius = '8px'; // Rounded corners
  popup.style.overflow = 'hidden'; // Ensures nothing spills out

  // Add a canvas for the graph
  const canvas = document.createElement('canvas');
  canvas.id = 'graphCanvas';
  canvas.style.width = '100%'; // Full width of the modal
  canvas.style.height = '300px'; // Fixed height for the canvas
  popup.appendChild(canvas);

  // Add close button
  const closeButton = document.createElement('button');
  closeButton.textContent = 'Close';
  closeButton.style.position = 'absolute';
  closeButton.style.top = '10px';
  closeButton.style.right = '10px';
  closeButton.style.padding = '5px 10px';
  closeButton.style.border = 'none';
  closeButton.style.background = '#f44336';
  closeButton.style.color = 'white';
  closeButton.style.borderRadius = '5px';
  closeButton.style.cursor = 'pointer';
  closeButton.onclick = function () {
    const existingPopup = document.getElementById(`graphPopup${registerAddress}`);
    if (existingPopup) {
      document.body.removeChild(existingPopup);
    }
  };
  popup.appendChild(closeButton);

  document.body.appendChild(popup);

  // Now call the function to draw the graph
  drawGraph(canvas.id, registerAddress);

  const lastValue = dataHistory[registerAddress][dataHistory[registerAddress].length - 1].value;
  const lastValueElement = document.createElement('div');
  lastValueElement.id = 'lastValue';
  lastValueElement.textContent = `Last Value: ${lastValue}`;
  lastValueElement.style.textAlign = 'center';
  lastValueElement.style.marginTop = '10px';
  lastValueElement.style.fontSize = '16px';
  lastValueElement.style.fontWeight = 'bold';
  popup.appendChild(lastValueElement);

  fetchSingleRegister(registerAddress);
}

function drawGraph(canvasId, registerAddress) {
  const ctx = document.getElementById(canvasId).getContext('2d');
  ctx.canvas.width = '100%';
  ctx.canvas.height = '300px';

  const values = dataHistory[registerAddress].map(item => item.value);
  const timestamps = dataHistory[registerAddress].map(item => item.timestamp);

  const minY = Math.min(...values);
  const maxY = Math.max(...values);

  if (chart) {
    chart.destroy(); // Destroy the existing chart instance
  }

  chart = new Chart(ctx, {
    type: 'line',  // Example: line graph
    data: {
      labels: timestamps, // Dynamic labels based on data count
      datasets: [{
        label: 'Values',
        data: values,  // Actual data from server
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
          min: minY - 1,
          max: maxY + 1
        }
      }
    }
  });
}

// Run fetchTableData function periodically every 15 seconds
setInterval(fetchTableData, 15000);

fetchTableData();
)rawliteral";
}
