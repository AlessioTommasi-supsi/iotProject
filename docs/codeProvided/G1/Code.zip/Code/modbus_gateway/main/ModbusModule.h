#ifndef ModbusModule_h
#define ModbusModule_h

#include <ModbusRTUMaster.h>
#include "CustomModbusRTUSlave.h"
#include <cmath> 
#include <stdlib.h>
#include "ModbusRegister.h"
#include "NumberConverter.h"

class ModbusModule {
  public:
    ModbusModule(const uint8_t masterDePin, const uint8_t slaveDePin);

    void masterBegin(const unsigned long baudRate, const uint8_t rxPin, const uint8_t txPin);
    void slaveBegin(const uint8_t slaveId, const unsigned long baudRate, const uint8_t rxPin, const uint8_t txPin);
    String readHoldingRegister(const HoldingRegister& holdingRegister);
    uint16_t readHoldingRegister(const uint16_t registerAddress);
    void readAllRegisters();
    void pollSlave();
    void setSlaveActive(const bool active);
    void setSwap(const bool swap);

    void addHoldingRegister(const HoldingRegister& holdingRegister) {_modbusRegister.addHoldingRegister(holdingRegister);};
    HoldingRegister* getHoldingRegister(int index) const {return _modbusRegister.getHoldingRegister(index);};
    HoldingRegister* getHoldingRegisterByAddress(const uint16_t registerAddress) const {return _modbusRegister.getHoldingRegisterByAddress(registerAddress);};
    int getHoldingRegisterIndexByAddress(const uint16_t registerAddress) const {return _modbusRegister.getHoldingRegisterIndexByAddress(registerAddress);}; 
    bool editHoldingRegister(int index, const HoldingRegister& holdingRegister) {return _modbusRegister.editHoldingRegister(index, holdingRegister);};
    bool removeHoldingRegister(int index) {return _modbusRegister.removeHoldingRegister(index);};
    String getHoldingRegistersJson() const {return _modbusRegister.getHoldingRegistersJson();};
    String getHoldingRegisterJson(const uint16_t registerAddress) const {return _modbusRegister.getHoldingRegisterJson(registerAddress);};
    void printHoldingRegisters() const {_modbusRegister.printHoldingRegisters();};
    int getRegistersCount() const {return _modbusRegister.getCount();};

  private:
    ModbusRTUMaster _modbusMaster;
    CustomModbusRTUSlave _modbusSlave;
    ModbusRegister _modbusRegister;
    bool _slaveActive;
    bool _swap = false;

    float _convertToFloat(const uint16_t a, const uint16_t b) const;
    uint32_t _convertToLong(const uint16_t a, const uint16_t b) const;
    uint32_t _convertToUint32(const float value, uint16_t &a, uint16_t &b) const;
    uint32_t _concatenate(const uint16_t high, const uint16_t low) const;
    void _divide(const uint32_t value, uint16_t &a, uint16_t &b) const;

};

#endif
