#include "WebServerConfig.h"

WebServerConfig::WebServerConfig(ModbusModule* modbus): _server(80), _modbus(modbus), _connectionInterval(5000){}

void WebServerConfig::setup(const char* ssid, const char* password){
  _ssid = ssid;
  _password = password;

  WiFi.mode(WIFI_AP_STA);
  WebServerConfig::_startCaptivePortal(ssid, password);

  _server.on("/", [this](){ this->_handleRoot(); });
  _server.on("/captivePortalScript.js", [this](){ this->_handleCaptivePortalJsScript(); });
  _server.on("/scanNetworks", [this](){ this->_handleScanNetworks(); });
  _server.on("/connect", HTTP_POST, [this](){ this->_handleWifiConnect(); });
  _server.on("/configuration", [this](){ this->_handleConfigurationPage(); });
  _server.on("/configurationScript.js", [this](){ this->_handleConfigurationJsScript(); });
  _server.on("/holdingRegisters", [this](){ this->_getHoldingRegistersJson(); });
  _server.on("/holdingRegister", [this](){ this->_getHoldingRegisterJson(); });
  _server.on("/add", HTTP_POST, [this](){ this->_addHoldingRegister(); });
  _server.on("/edit", HTTP_PUT, [this](){ this->_editHoldingRegister(); });
  _server.on("/delete", HTTP_DELETE, [this](){ this->_deleteHoldingRegister(); });
  _server.on("/slave", HTTP_PUT, [this](){ this->_editSlaveMode(); });
  _server.on("/swap", HTTP_PUT, [this](){ this->_editSwapMode(); });
  _server.onNotFound([this](){ this->_handleRoot(); });
  _server.begin();
}

void WebServerConfig::_startCaptivePortal(const char* ssid, const char* password){
  WiFi.softAP(ssid, password);
  Serial.println("Access Point Started");
  Serial.print("IP Address: ");
  Serial.println(WiFi.softAPIP());

  _dnsServer.start(53, "*", WiFi.softAPIP());
  _isDnsActive = true;
}

void WebServerConfig::_handleRoot() {
  String html = WebPages::getCaptivePortal();

  _server.send(200, "text/html", html);
}

void WebServerConfig::_handleCaptivePortalJsScript() {
  String js = WebPages::getCaptivePortalJs();

  _server.send(200, "application/javascript", js);
}

void WebServerConfig::_handleScanNetworks() {
  Serial.println("Scan start");
  int n = WiFi.scanNetworks();
  Serial.println("Scan done");

  String json = "[";
  for (int i = 0; i < n; ++i) {
    if (i != 0) {
      json += ",";
    }
    json += "{\"ssid\":\"" + WiFi.SSID(i) + "\",\"rssi\":" + String(WiFi.RSSI(i)) + "}";
  }
  json += "]";

  _server.send(200, "application/json", json);
}

void WebServerConfig::_handleWifiConnect() {
  if (!_server.hasArg("ssid") || !_server.hasArg("password")) {
    _server.send(400, "text/plain", "Missing ssid or password");
    return;
  }

  String ssid = _server.arg("ssid");
  String password = _server.arg("password");

  WiFi.begin(ssid.c_str(), password.c_str());
  Serial.print("Connecting to WiFi: ");
  Serial.print(ssid);
  Serial.print(", ");
  Serial.println(password);

  unsigned long startMillis = millis();
  unsigned long nowMillis = millis();
  // 3 = WL_CONNECTED
  while ((WiFi.status() != WL_CONNECTED) && (nowMillis - startMillis <= _connectionInterval)) {
    Serial.print(WiFi.status());
    Serial.print(", ");
    
    delay(1000);
    nowMillis = millis();
  }

  Serial.print("Connected? ");
  Serial.println(WiFi.isConnected());
  Serial.print("Ip: ");
  Serial.println(WiFi.localIP());

  if (WiFi.status() != WL_CONNECTED) {
    _server.send(500, "text/plain", "Failed to connect to WiFi");
  } else {
    String ip = WiFi.localIP().toString();
    _server.send(200, "text/plain", ip);

    delay(10000);

    WiFi.softAPdisconnect(true);
    _dnsServer.stop();
    _isDnsActive = false;

    Serial.println("AP and dns are down");
  }
}

void WebServerConfig::_handleConfigurationPage() {
  String html = WebPages::getConfigurationPage();

  _server.send(200, "text/html", html);
}

void WebServerConfig::_handleConfigurationJsScript() {
  String js = WebPages::getConfigurationPageJs();

  _server.send(200, "application/javascript", js);
}

void WebServerConfig::_getHoldingRegistersJson() {
  _server.send(200, "application/json", _modbus->getHoldingRegistersJson());
}

void WebServerConfig::_getHoldingRegisterJson(){
  const int registerAddress = _server.arg("address").toInt();

  HoldingRegister* holdingRegister = _modbus->getHoldingRegisterByAddress(registerAddress);

  if(holdingRegister == nullptr){
    _server.send(404, "text/html", "Register not found");
  }else{
    _server.send(200, "application/json", _modbus->getHoldingRegisterJson(holdingRegister->getRegisterAddress())); 
  }
}

void WebServerConfig::_addHoldingRegister(){
  const uint8_t slaveAddress = _server.arg("slaveAddress").toInt();
  const uint16_t registerAddress = _server.arg("registerAddress").toInt();
  const HoldingRegister::VariableType type = (HoldingRegister::VariableType) _server.arg("type").toInt();
  const bool readWrite = _server.arg("readWrite").toInt() == 0 ? false : true;
  const String label = _server.arg("label");
  const String description = _server.arg("description");
  const String unit = _server.arg("unit");

  Serial.printf("Slave Address: %d, Register Address: %d, Type: %d, Read/Write: %s, Label: %s, Description: %s, Unit: %s\n", slaveAddress, registerAddress, type, readWrite ? "Read/Write" : "Read Only", label.c_str(), description.c_str(), unit.c_str());

  HoldingRegister hr(slaveAddress, registerAddress, type, readWrite, label, description, unit);
  _modbus->addHoldingRegister(hr);

  _server.send(201, "application/json", "Register added");
}

void WebServerConfig::_editHoldingRegister(){
  uint8_t slaveAddress = _server.arg("slaveAddress").toInt();
  const uint16_t registerAddress = _server.arg("registerAddress").toInt();
  const HoldingRegister::VariableType type = (HoldingRegister::VariableType) _server.arg("type").toInt();
  const bool readWrite = _server.arg("readWrite").toInt() == 0 ? false : true;
  String label = _server.arg("label");
  String description = _server.arg("description");
  String unit = _server.arg("unit");

  Serial.printf("Slave Address: %d, Register Address: %d, Type: %d, Read/Write: %s, Label: %s, Description: %s, Unit: %s\n", slaveAddress, registerAddress, type, readWrite ? "Read/Write" : "Read Only", label.c_str(), description.c_str(), unit.c_str());

  HoldingRegister hr(slaveAddress, registerAddress, type, readWrite, label, description, unit);
  
  const int index = _modbus->getHoldingRegisterIndexByAddress(registerAddress);

  if(index == -1){
    _server.send(404, "text/html", "Register not found");
  }else{
    _modbus->editHoldingRegister(index, hr);

    _server.send(200, "application/json", "Register edited");
  }
}

void WebServerConfig::_deleteHoldingRegister(){
  const uint16_t registerAddress = _server.arg("registerAddress").toInt();

  Serial.printf("Register Address: %d\n", registerAddress);

  const int index = _modbus->getHoldingRegisterIndexByAddress(registerAddress);

  if(index == -1){
    _server.send(404, "text/html", "Register not found");
  }else{
    _modbus->removeHoldingRegister(index);

    _server.send(200, "application/json", "Register deleted");
  }
}

void WebServerConfig::_editSlaveMode(){
  const bool active = _server.arg("slave").toInt() == 0 ? false : true;

  Serial.printf("Slave: %s\n", active ? "Active" : "Inactive");

  _modbus->setSlaveActive(active);

  _server.send(200, "application/json", "Slave toggled");
}

void WebServerConfig::_editSwapMode(){
  const bool swap = _server.arg("swap").toInt() == 0 ? false : true;

  Serial.printf("Swap: %s\n", swap ? "Active" : "Inactive");

  _modbus->setSwap(swap);

  _server.send(200, "application/json", "Swap toggled");
}

void WebServerConfig::handleClientRequests() {
  if (WiFi.status() != WL_CONNECTED && !_isDnsActive) {
    _startCaptivePortal(_ssid, _password);
  }

  if(_isDnsActive){
    _dnsServer.processNextRequest();
  }

  _server.handleClient();
}
