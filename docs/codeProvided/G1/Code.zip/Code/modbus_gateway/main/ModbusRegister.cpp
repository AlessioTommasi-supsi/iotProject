#include "ModbusRegister.h"

ModbusRegister::ModbusRegister(const int capacity): _count(0), _capacity(capacity){
  if(capacity == 0){
    _holdingRegisters = nullptr;
  }else{
    _holdingRegisters = new HoldingRegister[capacity];
  }
}

ModbusRegister::~ModbusRegister() {
  if (_holdingRegisters != nullptr) {
    delete[] _holdingRegisters;
  }
}

void ModbusRegister::addHoldingRegister(const HoldingRegister& holdingRegister) {
  _ensureCapacity();
  _holdingRegisters[_count++] = holdingRegister;
}

HoldingRegister* ModbusRegister::getHoldingRegister(int index) const {
  if (index < 0 || index >= _count) {
    return nullptr;
  }

  return &_holdingRegisters[index];
}

HoldingRegister* ModbusRegister::getHoldingRegisterByAddress(const uint16_t registerAddress) const {
  int i = 0;
  int j = 0;
  int len = 0;
  HoldingRegister* result = nullptr;
  while(result == nullptr && i < _count){
    const HoldingRegister::VariableType type = _holdingRegisters[i].getType();

    switch (type){
    case HoldingRegister::HR_INTEGER:
      len = 1;
      break;
    case HoldingRegister::HR_FLOAT:
      len = 2;
      break;
    case HoldingRegister::HR_LONG_INTEGER:
      len = 2;
      break;
    }

    j = 0;
    while(result == nullptr && j < len){
      if ((_holdingRegisters[i].getRegisterAddress() + j) == registerAddress) {
        result = &_holdingRegisters[i];
      }

      j++;
    }

    i++;
  }

  return result;
}

int ModbusRegister::getHoldingRegisterIndexByAddress(const uint16_t registerAddress) const {
  int i = 0;
  int j = 0;
  int len = 0;
  int result = -1;
  while(result == -1 && i < _count){
    const HoldingRegister::VariableType type = _holdingRegisters[i].getType();

    switch (type){
    case HoldingRegister::HR_INTEGER:
      len = 1;
      break;
    case HoldingRegister::HR_FLOAT:
      len = 2;
      break;
    case HoldingRegister::HR_LONG_INTEGER:
      len = 2;
      break;
    }

    j = 0;
    while(result == -1 && j < len){
      if ((_holdingRegisters[i].getRegisterAddress() + j) == registerAddress) {
        result = i;
      }

      j++;
    }

    i++;
  }

  return result;
}

bool ModbusRegister::editHoldingRegister(int index, const HoldingRegister& holdingRegister) {
  if (index >= 0 && index < _count) {
    _holdingRegisters[index] = holdingRegister;

    return true;
  }

  return false;
}

bool ModbusRegister::removeHoldingRegister(int index) {
  if (index < 0 || index >= _count) return false;

  for (int i = index; i < _count - 1; i++) {
    _holdingRegisters[i] = _holdingRegisters[i + 1];
  }

  _count--;

  return true;
}

String ModbusRegister::getHoldingRegistersJson() const {
  const size_t capacity = JSON_ARRAY_SIZE(_count) + _count * JSON_OBJECT_SIZE(10);
  DynamicJsonDocument doc(capacity);
  
  JsonArray array = doc.to<JsonArray>();

  for (int i = 0; i < _count; i++) {
    JsonObject obj = array.createNestedObject();
    obj["slaveAddress"] = _holdingRegisters[i].getSlaveAddress();
    obj["registerAddress"] = _holdingRegisters[i].getRegisterAddress();
    obj["type"] = _holdingRegisters[i].getType();
    obj["readWrite"] = _holdingRegisters[i].isReadWrite() ? 1 : 0;
    obj["label"] = _holdingRegisters[i].getLabel();
    obj["description"] = _holdingRegisters[i].getDescription();
    obj["min"] = _holdingRegisters[i].getMinValue();
    obj["max"] = _holdingRegisters[i].getMaxValue();
    obj["unit"] = _holdingRegisters[i].getUnit();
    obj["value"] = _holdingRegisters[i].getValue();
  }

  String output;
  serializeJson(doc, output);
  return output;
};

String ModbusRegister::getHoldingRegisterJson(const uint16_t registerAddress) const{
  HoldingRegister* holdingRegister = ModbusRegister::getHoldingRegisterByAddress(registerAddress);

  if(holdingRegister == nullptr){
    return "{}";
  }

  const size_t capacity = JSON_OBJECT_SIZE(10);

  DynamicJsonDocument doc(capacity);
  
  JsonObject obj = doc.to<JsonObject>();
  
  obj["slaveAddress"] = holdingRegister->getSlaveAddress();
  obj["registerAddress"] = holdingRegister->getRegisterAddress();
  obj["type"] = holdingRegister->getType();
  obj["readWrite"] = holdingRegister->isReadWrite() ? 1 : 0;
  obj["label"] = holdingRegister->getLabel();
  obj["description"] = holdingRegister->getDescription();
  obj["min"] = holdingRegister->getMinValue();
  obj["max"] = holdingRegister->getMaxValue();
  obj["unit"] = holdingRegister->getUnit();
  obj["value"] = holdingRegister->getValue();

  String output;
  serializeJson(doc, output);
  return output;

};

void ModbusRegister::printHoldingRegisters() const {
  Serial.println(F(" ID | Addr | Type  | RW    | Label      | Description        | Min | Max | Unit | Value  "));
  Serial.println(F("-----------------------------------------------------------------------------------------"));

  for (int i = 0; i < _count; i++) {
    Serial.println(ModbusRegister::_buildTableRow(_holdingRegisters[i]));
  }

  Serial.println("");
}

void ModbusRegister::_ensureCapacity() {
  if (_count >= _capacity) {
    _capacity = (_capacity == 0) ? 1 : _capacity * 2;

    HoldingRegister* newArray = new HoldingRegister[_capacity];

    for (int i = 0; i < _count; i++) {
        newArray[i] = _holdingRegisters[i];
    }

    delete[] _holdingRegisters;

    _holdingRegisters = newArray;
  }
}

char* ModbusRegister::_buildTableRow(HoldingRegister& holdingRegister) const{
  static char buffer[128];

  sprintf(buffer, "%3d | %4d | %5d | %5s | %-10s | %-18s | %3d | %3d | %4s | %5s",
    holdingRegister.getSlaveAddress(),
    holdingRegister.getRegisterAddress(),
    holdingRegister.getType(),
    holdingRegister.isReadWrite() ? "RW" : "RO",
    holdingRegister.getLabel().c_str(),
    holdingRegister.getDescription().c_str(),
    holdingRegister.getMinValue(),
    holdingRegister.getMaxValue(),
    holdingRegister.getUnit().c_str(),
    holdingRegister.getValue());

  return buffer;
}