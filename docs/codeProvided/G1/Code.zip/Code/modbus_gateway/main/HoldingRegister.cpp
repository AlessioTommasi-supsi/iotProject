#include "HoldingRegister.h"

HoldingRegister::HoldingRegister(){}

HoldingRegister::HoldingRegister(const uint8_t slaveAddress, const uint16_t registerAddress, const VariableType type, const bool readWrite, const String label, const String description, const String unit, const int minValue, const int maxValue)
  : _slaveAddress(slaveAddress), _registerAddress(registerAddress), _type(type), _readWrite(readWrite), _label(label), _description(description), _unit(unit){

    HoldingRegister::_setMinValue(minValue);
    HoldingRegister::_setMaxValue(maxValue);
}

// HoldingRegister::HoldingRegister(const HoldingRegister& other)
//     : _slaveAddress(other._slaveAddress),
//       _registerAddress(other._registerAddress),
//       _type(other._type),
//       _readWrite(other._readWrite),
//       _label(other._label),
//       _description(other._description),
//       _minValue(other._minValue),
//       _maxValue(other._maxValue),
//       _unit(other._unit),
//       _value(other._value) {}

// HoldingRegister& HoldingRegister::operator=(const HoldingRegister& other) {
//   if (this != &other) {
//     _slaveAddress = other._slaveAddress;
//     _registerAddress = other._registerAddress;
//     _type = other._type;
//     _readWrite = other._readWrite;
//     _label = other._label;
//     _description = other._description;
//     _minValue = other._minValue;
//     _maxValue = other._maxValue;
//     _unit = other._unit;
//     _value = other._value;
//   }

//   return *this;
// }

String HoldingRegister::toString() const{
  String result = "Slave Address: " + String(_slaveAddress) + "\n";
  result += "Register Address: " + String(_registerAddress) + "\n";
  result += "Type: " + String(_type) + "\n";
  result += "Read/Write: " + String(_readWrite ? "Read/Write" : "Read Only") + "\n";
  result += "Label: " + _label + "\n";
  result += "Description: " + _description + "\n";
  result += "Min Value: " + _minValue != -1 + "\n";
  result += "Max Value: " + _maxValue != -1 + "\n";
  result += "Unit: " + _unit + "\n";
  result += "Value: " + _value;

  return result; 
}

void HoldingRegister::_setMinValue(int minValue){
  if(_readWrite){
    _minValue = minValue;
  }
}

void HoldingRegister::_setMaxValue(int maxValue){
  if(_readWrite){
    _maxValue = maxValue;
  }
}