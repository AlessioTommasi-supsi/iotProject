#include "ModbusModule.h"

ModbusModule::ModbusModule(const uint8_t masterDePin, const uint8_t slaveDePin): _modbusMaster(Serial1, masterDePin), _modbusSlave(Serial2, slaveDePin), _modbusRegister(){}

void ModbusModule::masterBegin(const unsigned long baudRate, const uint8_t rxPin, const uint8_t txPin){
  Serial.printf("Modbus master started with baudRate: %d, rxPin: %d, txPin: %d\n", baudRate, rxPin, txPin);
  _modbusMaster.begin(baudRate, SERIAL_8N1, rxPin, txPin);
}

void ModbusModule::slaveBegin(const uint8_t slaveId, const unsigned long baudRate, const uint8_t rxPin, const uint8_t txPin){
  Serial.printf("Modbus slave started with id: %d baudRate: %d, rxPin: %d, txPin: %d\n", slaveId, baudRate, rxPin, txPin);
  _modbusSlave.begin(slaveId, baudRate, SERIAL_8N1, rxPin, txPin);
  _modbusSlave.setHoldingRegistersCallback([this](uint16_t registerAddress) -> uint16_t { return this->readHoldingRegister(registerAddress); });

  _slaveActive = true;
}

String ModbusModule::readHoldingRegister(const HoldingRegister& holdingRegister) {
  const uint8_t id = holdingRegister.getSlaveAddress();
  const uint16_t address = holdingRegister.getRegisterAddress();
  uint16_t buffer[2] = {0, 0};
  uint16_t quantity = 0;
  const HoldingRegister::VariableType type = holdingRegister.getType();
  switch (type){
    case HoldingRegister::HR_INTEGER:
      quantity = 1;
      break;
    case HoldingRegister::HR_FLOAT:
      quantity = 2;
      break;
    case HoldingRegister::HR_LONG_INTEGER:
      quantity = 2;
      break;
  }

  // startAddress - 1 is required by the library to shift to the correct starting point
  const bool isValid = _modbusMaster.readHoldingRegisters(id, address - 1, buffer, quantity);

  if(!isValid){
    return "";
  }

  String result = "";

  switch (type){
    case HoldingRegister::HR_INTEGER:
      result = buffer[0];
      break;
    case HoldingRegister::HR_FLOAT:
      result = ModbusModule::_convertToFloat(buffer[0], buffer[1]);
      break;
    case HoldingRegister::HR_LONG_INTEGER:
      result = ModbusModule::_convertToLong(buffer[0], buffer[1]);
      break;
  }

  //Serial.println(result);

  return result;
}

uint16_t ModbusModule::readHoldingRegister(const uint16_t registerAddress) {
  HoldingRegister* holdingRegister = _modbusRegister.getHoldingRegisterByAddress(registerAddress);
  uint16_t result = 0;

  if(holdingRegister == nullptr){
    Serial.printf("Register: %d nullptr\n", registerAddress);
    return 0;
  }

   Serial.printf("Register required: %d, found: %d\n", registerAddress, holdingRegister->getRegisterAddress());

  const HoldingRegister::VariableType type = holdingRegister->getType();
  String value = holdingRegister->getValue();
  uint16_t holdingRegisterAddress = holdingRegister->getRegisterAddress();
  uint16_t a, b;
  float floatValue;
  long longValue;
  switch (type){
    case HoldingRegister::HR_INTEGER:
      a = strtol(value.c_str(), NULL, 0);
      Serial.printf("int: %d\n", a);
      break;
    case HoldingRegister::HR_FLOAT:
      floatValue = value.toFloat();
      ModbusModule::_convertToUint32(floatValue, a, b);
      Serial.printf("float: %0.2f, a: %d, b %d\n", floatValue, a, b);
      break;
    case HoldingRegister::HR_LONG_INTEGER:
      longValue = value.toInt();
      ModbusModule::_divide(longValue, a, b);

      break;
  }

  if(registerAddress == holdingRegisterAddress){
    result = a;
  }else{
    result = b;
  }

  return result;
}

void ModbusModule::readAllRegisters(){
  const int count = ModbusModule::getRegistersCount();

  for(int i = 0; i < count; i++){
    HoldingRegister* currentRegister = ModbusModule::getHoldingRegister(i);

    if(currentRegister != nullptr){
      const String value = String(ModbusModule::readHoldingRegister(*currentRegister));
    
      currentRegister->setValue(value);
      ModbusModule::editHoldingRegister(i, *currentRegister);
    }
  }
}

void ModbusModule::pollSlave(){
  if(_slaveActive){
    _modbusSlave.poll();
  }
}

void ModbusModule::setSlaveActive(const bool active){
  _slaveActive = active;
}

void ModbusModule::setSwap(const bool swap){
  _swap = swap;
}

float ModbusModule::_convertToFloat(const uint16_t a, const uint16_t b) const{
  uint32_t uintValue = 0;
  if(_swap){
    uintValue = ModbusModule::_concatenate(b, a);
  }else{
    uintValue = ModbusModule::_concatenate(a, b);
  }

  return NumberConverter::uint32ToFloat(uintValue);
}

uint32_t ModbusModule::_convertToLong(const uint16_t a, const uint16_t b) const{
  uint32_t uintValue = 0;
  if(_swap){
    uintValue = ModbusModule::_concatenate(b, a);
  }else{
    uintValue = ModbusModule::_concatenate(a, b);
  }

  return uintValue;
}

uint32_t ModbusModule::_convertToUint32(const float value, uint16_t &a, uint16_t &b) const{
  uint32_t uintValue = 0;

  uintValue = NumberConverter::floatToUint32(value);

  ModbusModule::_divide(uintValue, a, b);

  return uintValue;
}

uint32_t ModbusModule::_concatenate(const uint16_t high, const uint16_t low) const {
  return (static_cast<uint32_t>(high) << 16) | low;
}

void ModbusModule::_divide(const uint32_t value, uint16_t &a, uint16_t &b) const {
  if(_swap){
    b = (value >> 16) & 0xFFFF;
    a = value & 0xFFFF;
  }else{
    a = (value >> 16) & 0xFFFF;
    b = value & 0xFFFF;
  }
}
