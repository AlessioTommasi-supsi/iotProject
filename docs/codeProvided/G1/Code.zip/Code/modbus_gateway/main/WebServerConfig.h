#ifndef WebServerConfig_h
#define WebServerConfig_h

#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Arduino.h>
#include "ModbusModule.h"
#include "HoldingRegister.h"
#include "WebPages.h"

class WebServerConfig {
  public:
    WebServerConfig(ModbusModule* modbus = nullptr);

    void setup(const char* ssid, const char* password = NULL);
    void handleClientRequests();

  private:
    WebServer _server;
    DNSServer _dnsServer;
    ModbusModule* _modbus;
    const char* _ssid;
    const char* _password;
    unsigned long _connectionInterval;
    bool _isDnsActive = false;

    void _startCaptivePortal(const char* ssid, const char* password);
    void _handleRoot();
    void _handleCaptivePortalJsScript();
    void _handleScanNetworks();
    void _handleWifiConnect();
    void _handleConfigurationPage();
    void _handleConfigurationJsScript();
    void _getHoldingRegistersJson();
    void _getHoldingRegisterJson();
    void _addHoldingRegister();
    void _editHoldingRegister();
    void _deleteHoldingRegister();
    void _editSlaveMode();
    void _editSwapMode();
};

#endif
