#ifndef WebPages_h
#define WebPages_h

#include <Arduino.h>

class WebPages {
  public:
    static String getCaptivePortal();
    static String getCaptivePortalJs();

    static String getConfigurationPage();
    static String getConfigurationPageJs();
};

#endif
