#ifndef ModbusRegister_h
#define ModbusRegister_h

#include <Arduino.h>
// #include <stdint.h>
#include <ArduinoJson.h>
#include "HoldingRegister.h"


class ModbusRegister {
  public:
    ModbusRegister(const int capacity = 10);
    ~ModbusRegister();

    void addHoldingRegister(const HoldingRegister& holdingRegister);
    HoldingRegister* getHoldingRegister(int index) const;
    HoldingRegister* getHoldingRegisterByAddress(const uint16_t registerAddress) const;
    int getHoldingRegisterIndexByAddress(const uint16_t registerAddress) const;
    bool editHoldingRegister(int index, const HoldingRegister& holdingRegister);
    bool removeHoldingRegister(int index);
    String getHoldingRegistersJson() const;
    String getHoldingRegisterJson(const uint16_t registerAddress) const;
    void printHoldingRegisters() const;

    int getCount() const {return _count;};

  private:
    HoldingRegister* _holdingRegisters;
    int _count;
    int _capacity;

    void _ensureCapacity();
    char*  _buildTableRow(HoldingRegister& holdingRegister) const;

};

#endif
