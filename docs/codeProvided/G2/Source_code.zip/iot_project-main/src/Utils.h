#ifndef UTILS_H
#define UTILS_H

#include <stdint.h>
#include <cmath>

float convertToFloat(uint16_t register1, uint16_t register2);

#endif